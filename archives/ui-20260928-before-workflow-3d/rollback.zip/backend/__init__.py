"""Local manufacturing analytics API."""
