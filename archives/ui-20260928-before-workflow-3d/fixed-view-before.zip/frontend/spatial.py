"""Data-linked logical inspection models. Coordinates are illustrative, not CAD."""
import math
import re
import plotly.graph_objects as go
from plotly.colors import sample_colorscale
from dash import Input, Output, State, dcc, html, no_update, ctx
import dash_mantine_components as dmc
from frontend.components import BLUE, CYAN, RED, TEXT

CAMERA = {'eye': {'x': 1.65, 'y': -2.2, 'z': 2.2}, 'projection': {'type': 'perspective'}}
SCALE = [[0, '#C6D9EA'], [.5, '#527FA9'], [1, BLUE]]
FACES = [(0,1,2),(0,2,3),(4,5,6),(4,6,7),(0,1,5),(0,5,4),(1,2,6),(1,6,5),(2,3,7),(2,7,6),(3,0,4),(3,4,7)]


def box(x, y, z, w, d, h):
    return [(x,y,z),(x+w,y,z),(x+w,y+d,z),(x,y+d,z),
            (x,y,z+h),(x+w,y,z+h),(x+w,y+d,z+h),(x,y+d,z+h)]


def mesh(boxes, name):
    """One mesh per layer keeps 176 selectable cells inexpensive to render."""
    vertices, faces, colors, custom, labels = [], [], [], [], []
    for corners, color, key, label in boxes:
        offset = len(vertices)
        vertices.extend(corners)
        faces.extend(tuple(offset+i for i in face) for face in FACES)
        colors.extend([color]*8)
        custom.extend([[key]]*8)
        labels.extend([label]*8)
    return go.Mesh3d(x=[p[0] for p in vertices],y=[p[1] for p in vertices],z=[p[2] for p in vertices],
        i=[f[0] for f in faces],j=[f[1] for f in faces],k=[f[2] for f in faces],vertexcolor=colors,
        customdata=custom,text=labels,hovertemplate='%{text}<extra></extra>',name=name,showlegend=False,
        flatshading=True,lighting={'ambient':.75,'diffuse':.7,'specular':.12,'roughness':.8},
        lightposition={'x':-50,'y':-80,'z':100})


def outline(corners, label):
    x,y,z = [],[],[]
    for a,b in [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]:
        for v in (corners[a],corners[b],(None,None,None)):
            x.append(v[0]);y.append(v[1]);z.append(v[2])
    return go.Scatter3d(x=x,y=y,z=z,mode='lines',line={'color':CYAN,'width':6},hoverinfo='skip',name=label,showlegend=False)


def scene(fig, revision, height=390):
    axis={'visible':False,'showgrid':False,'zeroline':False,'showbackground':False}
    fig.update_layout(height=height,margin={'l':0,'r':0,'t':0,'b':0},paper_bgcolor='white',
        font={'family':'SUIT Variable, sans-serif','size':14,'color':TEXT,'weight':550},
        scene={'xaxis':axis,'yaxis':axis,'zaxis':axis,'camera':CAMERA,'aspectmode':'data',
               'dragmode':'orbit','bgcolor':'white','uirevision':revision},uirevision=revision,
        hoverlabel={'bgcolor':BLUE,'font':{'color':'white','size':14}},showlegend=False)
    return fig


def quality_figure(data, mode='cell'):
    temperature=mode=='temperature'
    channels=data['snapshot']['temperatures' if temperature else 'cells']
    values=[p['value'] for p in channels if p['value'] is not None and math.isfinite(p['value'])]
    low,high=(min(values),max(values)) if values else (0,1)
    base,cells,centers=[],[],[]; selected=None
    unit='°C' if temperature else 'V'
    for module in range(1,17):
        x=((module-1)%4)*4.5; y=((module-1)//4)*3.25
        base.append((box(x-.12,y-.12,-.2,4.18,2.75,.23),'#DCE3EC','',f'M{module:02d} · 논리 모듈'))
        centers.append((x+1.9,y-.4,0,f'M{module:02d}'))
    for p in channels:
        module=int(p['id'][1:3]);channel=int(p['id'][-2:])
        x=((module-1)%4)*4.5; y=((module-1)//4)*3.25
        corners=box(x+(channel-1)*(2.0 if temperature else .36),y,.04,1.8 if temperature else .25,2.4,.7)
        value=p['value']; valid=value is not None and math.isfinite(value)
        color=sample_colorscale(SCALE,[(value-low)/(high-low) if valid and high>low else .5])[0] if valid else '#7D8282'
        # Red means a raw measurement check, never an invented cell defect diagnosis.
        if p['invalid']:color=RED
        text=f"{p['id']}<br>{value:.3f} {unit}" if valid else f"{p['id']}<br>측정값 없음"
        text+=f"<br>원본값 확인 필요" if p['invalid'] else ''
        cells.append((corners,color,p['id'],text))
        if p['id']==data['selectedCell']:selected=corners
    fig=go.Figure([mesh(base,'모듈 받침'),mesh(cells,'측정 채널')])
    fig.add_trace(go.Scatter3d(x=[c[0] for c in centers],y=[c[1] for c in centers],z=[c[2] for c in centers],
        text=[c[3] for c in centers],mode='text',textfont={'size':12,'color':TEXT},hoverinfo='skip',showlegend=False))
    # Thin top seams keep equal-valued adjacent cells individually legible.
    ex,ey,ez=[],[],[]
    for corners,_,_,_ in cells:
        for idx in (4,5,6,7,4):
            a,b,c=corners[idx];ex.append(a);ey.append(b);ez.append(c+.005)
        ex.append(None);ey.append(None);ez.append(None)
    fig.add_trace(go.Scatter3d(x=ex,y=ey,z=ez,mode='lines',line={'color':'#E5EDF5','width':1.5},hoverinfo='skip',showlegend=False))
    if selected:fig.add_trace(outline(selected,'선택 셀'))
    if values:
        fig.add_trace(go.Scatter3d(x=[None],y=[None],z=[None],mode='markers',hoverinfo='skip',
            marker={'color':[low],'colorscale':SCALE,'cmin':low,'cmax':high if high>low else low+1e-6,
                'showscale':True,'colorbar':{'title':unit,'thickness':10,'len':.6}},showlegend=False))
    return scene(fig,'quality-'+data['testId']+'-'+mode)


def maintenance_figure(data, points, selected=None):
    items=[]; chosen=None
    for p in points:
        index=int(p['page'])-1; x=(index%13)*1.15;y=(index//13)*1.6
        corners=box(x,y,0,.9,1.25,.34)
        color=TEXT if p['power']==0 else RED if p['prediction'] else '#AFC5DA'
        items.append((corners,color,str(p['row']),f"지점 {p['page']:02d} · {p['power']:,.1f} W<br>위험비 {p['risk']:.2f}배<br>{p['agreement']}"))
        if p['row']==selected:chosen=corners
    fig=go.Figure([mesh([(box(-.25,-.25,-.23,15.15,5.25,.2),'#E8EDF3','','논리 지점판')],'받침'),mesh(items,'용접 지점')])
    fig.add_trace(go.Scatter3d(x=[((int(p['page'])-1)%13)*1.15+.45 for p in points],
        y=[((int(p['page'])-1)//13)*1.6+.625 for p in points],z=[.37]*len(points),
        mode='text',text=[f"{p['page']:02d}" for p in points],customdata=[[str(p['row'])] for p in points],
        textfont={'color':'white','size':13},hoverinfo='skip',showlegend=False))
    if chosen:fig.add_trace(outline(chosen,'선택 지점'))
    return scene(fig,'maintenance-'+data['run']+'-'+str(points[0]['cycle']),330)


def graph3d(figure, id):
    return html.Div([dcc.Graph(id=id,figure=figure,config={'displayModeBar':False,'responsive':True,'scrollZoom':False}),
        html.Div([html.Span('드래그 회전 · 지점 선택 · 2D로 전환 가능'),
                  dmc.Button('시점 초기화',id=id+'-reset',variant='subtle',size='xs')],className='spatial-help')],className='spatial-canvas')


def selection(click, allowed):
    """Only accept data IDs actually present in the currently shown dataset."""
    points=(click or {}).get('points') or []
    custom=points[0].get('customdata') if points else None
    value=custom[0] if isinstance(custom,list) and custom else None
    return value if value in allowed else None


def toggle(id, current='3d'):
    return html.Div([html.Button(label,id=id+'-'+value,n_clicks=0,
        className='view-mode-button'+(' selected' if current==value else ''),
        **{'aria-pressed':str(current==value).lower()}) for value,label in [('3d','3D'),('2d','2D')]],className='view-mode-switch',role='group',**{'aria-label':'검사 보기'})


def register(app):
    for prefix in ('q','m'):
        def mode(a,b,current):
            if not a and not b:return (no_update,)*5
            value='2d' if ctx.triggered_id.endswith('-2d') else '3d'
            return (value if value!=current else no_update,'view-mode-button'+(' selected' if value=='3d' else ''),
                    'view-mode-button'+(' selected' if value=='2d' else ''),str(value=='3d').lower(),str(value=='2d').lower())
        app.callback(Output(prefix+'-spatial-mode','data'),Output(prefix+'-view-3d','className'),Output(prefix+'-view-2d','className'),
            Output(prefix+'-view-3d','aria-pressed'),Output(prefix+'-view-2d','aria-pressed'),
            Input(prefix+'-view-3d','n_clicks',allow_optional=True),Input(prefix+'-view-2d','n_clicks',allow_optional=True),State(prefix+'-spatial-mode','data'),prevent_initial_call=True)(mode)
    @app.callback(Output('m-view-3d','className',allow_duplicate=True),Output('m-view-2d','className',allow_duplicate=True),
        Output('m-view-3d','aria-pressed',allow_duplicate=True),Output('m-view-2d','aria-pressed',allow_duplicate=True),
        Input('view-data','data'),State('m-spatial-mode','data'),prevent_initial_call=True)
    def restore_view(view, value):
        if not view or view.get('domain')!='maintenance' or view.get('tab')!='analysis':return (no_update,)*4
        return ('view-mode-button'+(' selected' if value=='3d' else ''),'view-mode-button'+(' selected' if value=='2d' else ''),str(value=='3d').lower(),str(value=='2d').lower())

    for id in ('quality-3d','maintenance-3d'):
        def reset(n, fig):
            if not n or not fig:return no_update
            fig['layout']['scene']['camera']=CAMERA
            fig['layout']['scene']['uirevision']='reset-'+str(n)
            return fig
        app.callback(Output(id,'figure'),Input(id+'-reset','n_clicks',allow_optional=True),State(id,'figure',allow_optional=True),prevent_initial_call=True)(reset)
