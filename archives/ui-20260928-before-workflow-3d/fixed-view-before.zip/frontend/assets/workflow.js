// A disclosure action menu closes after choosing an action or pressing Escape.
document.addEventListener('click', event => {
  const menu = document.getElementById('file-actions');
  if (!menu || !menu.open) return;
  if (!menu.contains(event.target) || event.target.closest('button')) menu.open = false;
});
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;
  const menu = document.getElementById('file-actions');
  if (menu?.open) {
    menu.open = false;
    menu.querySelector('summary')?.focus();
  }
});
